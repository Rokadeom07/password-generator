/* =========================================================
   PASSWORD GENERATOR - LOGIC
   Plain JavaScript, no frameworks or external libraries.
   ========================================================= */

/* ---------- Character sets ---------- */
const CHAR_SETS = {
  uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
  lowercase: 'abcdefghijklmnopqrstuvwxyz',
  numbers: '0123456789',
  special: '!@#$%^&*()_+-=[]{}|;:,.<>?'
};

/* ---------- Grab DOM elements once, reuse everywhere ---------- */
const lengthSlider = document.getElementById('lengthSlider');
const lengthInput = document.getElementById('lengthInput');

const checkboxes = {
  uppercase: document.getElementById('includeUppercase'),
  lowercase: document.getElementById('includeLowercase'),
  numbers: document.getElementById('includeNumbers'),
  special: document.getElementById('includeSpecial')
};

const errorMessage = document.getElementById('errorMessage');
const generateBtn = document.getElementById('generateBtn');

const passwordOutput = document.getElementById('passwordOutput');
const passwordText = document.getElementById('passwordText');
const copyBtn = document.getElementById('copyBtn');

const strengthBar = document.getElementById('strengthBar');
const strengthText = document.getElementById('strengthText');

const historyList = document.getElementById('historyList');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');

/* Key used to store the password history in sessionStorage.
   sessionStorage keeps data only for the current browser tab/session,
   which matches the "history during the current browser session" requirement. */
const HISTORY_KEY = 'pwgen_history';

let currentPassword = '';

/* =========================================================
   RANDOMNESS HELPERS
   We use the Web Crypto API (crypto.getRandomValues) instead of
   Math.random(), because it produces cryptographically strong
   random numbers - a better fit for a password generator.
   ========================================================= */

// Returns a random integer in the range [0, max) using crypto randomness.
function secureRandomInt(max) {
  const array = new Uint32Array(1);
  crypto.getRandomValues(array);
  return array[0] % max;
}

// Picks one random character out of a string.
function randomCharFrom(charSet) {
  return charSet[secureRandomInt(charSet.length)];
}

// Fisher-Yates shuffle, using secureRandomInt so the final character
// order is unpredictable (not just the character choice).
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = secureRandomInt(i + 1);
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

/* =========================================================
   PASSWORD GENERATION
   ========================================================= */

// Reads which checkboxes are currently checked.
function getSelectedOptions() {
  return {
    uppercase: checkboxes.uppercase.checked,
    lowercase: checkboxes.lowercase.checked,
    numbers: checkboxes.numbers.checked,
    special: checkboxes.special.checked
  };
}

/**
 * Builds a password that:
 *  - only uses characters from the selected categories
 *  - contains at least one character from EACH selected category
 *  - is exactly `length` characters long (or longer, if length is too
 *    small to fit one of every selected category)
 */
function generatePassword(length, options) {
  let pool = '';
  const mandatoryChars = [];

  // For every selected category: add it to the shared pool AND
  // guarantee one random character from it goes into the password.
  Object.keys(options).forEach((key) => {
    if (options[key]) {
      pool += CHAR_SETS[key];
      mandatoryChars.push(randomCharFrom(CHAR_SETS[key]));
    }
  });

  if (pool === '') {
    return null; // nothing selected - caller must validate before this
  }

  // If the requested length can't even fit one of each selected type,
  // stretch the length so every mandatory character still fits.
  const finalLength = Math.max(length, mandatoryChars.length);

  const remainingCount = finalLength - mandatoryChars.length;
  const remainingChars = [];
  for (let i = 0; i < remainingCount; i++) {
    remainingChars.push(randomCharFrom(pool));
  }

  // Combine mandatory + random characters, then shuffle so the
  // mandatory ones aren't always sitting at the start of the string.
  const allChars = shuffleArray(mandatoryChars.concat(remainingChars));
  return allChars.join('');
}

/* =========================================================
   STRENGTH METER
   Simple scored heuristic based on length + variety of
   character categories used. Good enough for a learning project.
   ========================================================= */

function calculateStrength(length, options) {
  const categoryCount = Object.values(options).filter(Boolean).length;

  let score = 0;
  if (length >= 8) score++;
  if (length >= 12) score++;
  if (length >= 16) score++;
  if (categoryCount >= 3) score++;
  if (categoryCount === 4) score++;

  if (score <= 1) return { level: 'weak', label: 'Weak' };
  if (score <= 3) return { level: 'medium', label: 'Medium' };
  if (score <= 4) return { level: 'strong', label: 'Strong' };
  return { level: 'very-strong', label: 'Very strong' };
}

function renderStrength(length, options) {
  const { level, label } = calculateStrength(length, options);

  strengthBar.className = 'strength-bar ' + level;
  strengthText.className = 'strength-text ' + level;
  strengthText.textContent = label;
}

function resetStrength() {
  strengthBar.className = 'strength-bar';
  strengthText.className = 'strength-text';
  strengthText.textContent = '--';
}

/* =========================================================
   ERROR HANDLING
   ========================================================= */

function showError(message) {
  errorMessage.textContent = message;
  errorMessage.classList.remove('show');
  // Force reflow so the shake animation can re-trigger on repeated errors.
  void errorMessage.offsetWidth;
  errorMessage.classList.add('show');
}

function clearError() {
  errorMessage.textContent = '';
  errorMessage.classList.remove('show');
}

/* =========================================================
   RENDERING THE GENERATED PASSWORD
   ========================================================= */

function renderPassword(password) {
  passwordText.textContent = password;
  passwordText.classList.add('has-password');
  passwordOutput.classList.add('is-filled');
}

/* =========================================================
   HISTORY (stored in sessionStorage as a JSON array of strings)
   ========================================================= */

function loadHistory() {
  const raw = sessionStorage.getItem(HISTORY_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveToHistory(password) {
  const history = loadHistory();
  history.unshift(password); // newest password first
  sessionStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  renderHistory();
}

function clearHistory() {
  sessionStorage.removeItem(HISTORY_KEY);
  renderHistory();
}

function renderHistory() {
  const history = loadHistory();
  historyList.innerHTML = '';

  if (history.length === 0) {
    historyList.innerHTML = '<li class="history-empty">No passwords generated yet.</li>';
    return;
  }

  history.forEach((pwd) => {
    const item = document.createElement('li');
    item.className = 'history-item';
    item.innerHTML = `
      <span class="h-arrow">&gt;</span>
      <span class="h-password">${pwd}</span>
      <button class="h-copy" type="button">copy</button>
    `;
    item.querySelector('.h-copy').addEventListener('click', (e) => {
      copyTextToClipboard(pwd, e.target);
    });
    historyList.appendChild(item);
  });
}

/* =========================================================
   CLIPBOARD
   ========================================================= */

function copyTextToClipboard(text, buttonEl) {
  navigator.clipboard.writeText(text).then(() => {
    const original = buttonEl.textContent;
    buttonEl.textContent = 'copied!';
    buttonEl.classList.add('copied');
    setTimeout(() => {
      buttonEl.textContent = original;
      buttonEl.classList.remove('copied');
    }, 1200);
  });
}

/* =========================================================
   EVENT WIRING
   ========================================================= */

// Keep the slider and the number input synced with each other.
lengthSlider.addEventListener('input', () => {
  lengthInput.value = lengthSlider.value;
});
lengthInput.addEventListener('input', () => {
  let value = parseInt(lengthInput.value, 10);
  if (isNaN(value)) return;
  value = Math.min(50, Math.max(4, value));
  lengthSlider.value = value;
});

// Main "Generate password" action.
generateBtn.addEventListener('click', () => {
  const options = getSelectedOptions();
  const anySelected = Object.values(options).some(Boolean);

  if (!anySelected) {
    showError('Select at least one character type to generate a password.');
    return;
  }

  clearError();

  let length = parseInt(lengthInput.value, 10);
  if (isNaN(length) || length < 4) length = 4;
  if (length > 50) length = 50;
  lengthInput.value = length;
  lengthSlider.value = length;

  currentPassword = generatePassword(length, options);
  renderPassword(currentPassword);
  renderStrength(length, options);
  saveToHistory(currentPassword);
});

// Copy button next to the main password output.
copyBtn.addEventListener('click', () => {
  if (!currentPassword) return;
  copyTextToClipboard(currentPassword, copyBtn);
});

// Clear history button.
clearHistoryBtn.addEventListener('click', clearHistory);

/* ---------- Initial render on page load ---------- */
resetStrength();
renderHistory();
